package Mypackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Employee {
	
	public void createConnection()
	{
		try {
			String url = "jdbc:mysql://localhost:3306";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			System.out.println("Connection Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	public void createDatabase()
	{
		try {
			String url = "jdbc:mysql://localhost:3306";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="create database student";
			stm.execute(query);
			
			System.out.println("Databnase created Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

	public void createTable()
	{
		try {
			String url = "jdbc:mysql://localhost:3306/student";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="create table emp(empid int(3),empname varchar(255),empemail varchar(255))";
			stm.execute(query);
			
			System.out.println("Table created Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

	public void createData()
	{
		try {
			String url = "jdbc:mysql://localhost:3306/student";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="insert into emp(empid,empname,empemail)values(5,'Manesh','Manesh@123')";
			stm.execute(query);
			
			System.out.println("Data inserted Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
	}

	public void readData()
	{
		try {
			String url = "jdbc:mysql://localhost:3306/student";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="select * from emp";
			
			ResultSet res = stm.executeQuery(query);
			
			while(res.next())
			{
				System.out.println("id =" +res.getInt(1));
				System.out.println("name =" +res.getString(2));
				System.out.println("email =" +res.getString(3));
			}
			
			System.out.println("Data Read Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}

	public void updateData()
	{
		try {
			String url = "jdbc:mysql://localhost:3306/student";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="update emp set empid =6 where empname = 'Manesh' ";
			stm.execute(query);
			
			System.out.println("Data Updated Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}

	public void deleteData() 
	{
		try {
			String url = "jdbc:mysql://localhost:3306/student";
			String userName = "root";
			String passWord = "Manesh@123";
			
			Connection con =DriverManager.getConnection(url,userName,passWord);
			
			//create Statement 
			Statement stm = con.createStatement();
			
			//Execute query
			String query ="delete from emp where empid =4 ";
			stm.execute(query);
			
			System.out.println("Data Deleted Successfully...........!");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}
}
	