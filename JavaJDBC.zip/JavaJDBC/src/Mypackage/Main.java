package Mypackage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args)  {
		
	Employee e = new Employee();
	
//	e.createConnection();
	
//	e.createDatabase();
	
//	e.createTable();
	
//	e.createData();
	
	e.readData();
	
//	e.updateData();
	
//	e.deleteData();
	
	
	
	}
}
