/**
 * 
 */
/**
 * @author DELL
 *
 */
module JavaJDBC {
	requires java.sql;
}